<?php

class I18N
{
    public function __invoke($text) {
        return $text;
    }
}
