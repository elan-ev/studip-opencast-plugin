<?php

namespace Opencast\Errors;

use RuntimeException;
use Opencast\Errors\Error;

class UnprocessableEntityException extends Error
{
}
